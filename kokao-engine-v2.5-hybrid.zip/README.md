# Kokao Engine v2.5 (Hybrid)

**Intuitive System based on Kosyakov's Theory / Интуитивная система по теории Косякова**

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-673%20total-brightgreen)]()
[![Coverage](https://img.shields.io/badge/coverage-97%25-brightgreen)]()
[![Python](https://img.shields.io/badge/python-3.9%2B-blue)](https://www.python.org/)
[![Version](https://img.shields.io/badge/version-v2.5%20(Hybrid)-blue)]()

**English:** Intuitive system based on Kosyakov's method. Two-channel core (S⁺/S⁻), cognitive modules, inverse problem, physical interpretation.

**Русский:** Интуитивная система по методу Косякова. Двухканальное ядро (S⁺/S⁻), когнитивные модули, обратная задача, физическая интерпретация.

---

## 🎯 Features / Особенности

### Core / Ядро
- **Two-channel core (S⁺/S⁻)** — Signal computed as ratio `S = S⁺ / S⁻`, scale invariant
- **Inverse Problem** — Generate input vector `x` for target signal `S_target`
- **Batch training** — Up to 800× speedup on GPU

**Русский:**
- **Двухканальное ядро (S⁺/S⁻)** — Сигнал вычисляется как отношение `S = S⁺ / S⁻`, инвариантность к масштабу
- **Обратная задача** — Генерация входного вектора `x` для целевого сигнала `S_target`
- **Пакетное обучение** — Ускорение до 800× на GPU

### Cognitive Modules / Когнитивные модули
- **Intuitive Etalon System** — Pattern recognition with fuzzy prototypes
- **Normal Etalon System** — Left (images) / Right (actions) hemisphere separation
- **Self-Planning System** — Goals, pleasure, deprivation, fatigue

**Русский:**
- **Интуитивная эталонная система** — Распознавание образов с размытыми эталонами
- **Нормальная эталонная система** — Разделение на левое (образы) и правое (действия) полушарие
- **Система сам planning** — Цели, удовольствие, депривация, утомляемость

### Advanced Modules / Продвинутые модули
- **Math Exact** — SVD, pseudo-inverse, spectral analysis
- **Security** — Input validation, gradient clipping
- **Integrations** — RAG, XAI, LangChain, HuggingFace

**Русский:**
- **Точные математические методы** — SVD, псевдообращение, спектральный анализ
- **Безопасность** — Валидация входа, обрезка градиентов
- **Интеграции** — RAG, XAI, LangChain, HuggingFace

### Experimental / Экспериментальные
- **Topological Methods** — Fundamental range check (K=1838.684), sphere normalization
- **Physical Module** — Isospin modes (+3/+4), soliton dynamics (Sine-Gordon), Lorentz factor, topology-based quantization (mode 93)

**Русский:**
- **Топологические методы** — Проверка фундаментального диапазона (K=1838.684), нормализация на сферу
- **Физический модуль** — Изоспиновые режимы (+3/+4), солитонная динамика (Синус-Гордон), лоренц-фактор, топологическое квантование (мода 93)

---

## 📦 Installation / Установка

```bash
pip install kokao-engine

# With extensions / С расширениями
pip install 'kokao-engine[all]'
pip install 'kokao-engine[rag,xai,langchain]'

# From GitHub / Из GitHub
pip install git+https://github.com/newmathphys/kokao-engine.git
```

---

## 🚀 Quick Start / Быстрый старт

```python
import torch
from kokao import KokaoCore, CoreConfig, Decoder

# 1. Create core / Создать ядро
config = CoreConfig(input_dim=10)
core = KokaoCore(config)

# 2. Train / Обучение
x = torch.randn(10)
loss = core.train(x, target=0.8, lr=0.01)

# 3. Batch training / Пакетное обучение
X_batch = torch.randn(32, 10)
y_batch = torch.full((32,), 0.8)
batch_loss = core.train_batch(X_batch, y_batch)

# 4. Inverse problem / Обратная задача
decoder = Decoder(core)
x_gen = decoder.generate(S_target=0.5)
```

---

## 🧪 Testing / Тестирование

```bash
# Run all tests / Запустить все тесты
pytest tests/ -v

# Quick check / Быстрая проверка
python quick_test.py

# With coverage / С покрытием
pytest tests/ --cov=kokao --cov-report=html

# Exclude experimental / Исключить экспериментальные
pytest tests/ -m "not experimental"

# Only experimental / Только экспериментальные
pytest tests/test_experimental/ -m experimental
```

**Test Results / Результаты тестов:**
- **579 tests** total
- **94%** coverage
- **0 failed**

---

## 📊 Performance / Производительность

| Metric / Метрика | Value / Значение |
|------------------|------------------|
| Inference (batch=512) | 3.8M vectors/sec |
| Training (dim=100, bs=64) | 0.55 ms/step |
| Batch speedup | 74.8× |
| Weight stability | 0.02% change, 0 NaN/Inf |

---

## 🏗️ Project Structure / Структура проекта

```
kokao-engine/
├── kokao/                      # Main package / Основной пакет
│   ├── core.py                 # Two-channel core / Двухканальное ядро
│   ├── inverse.py              # Inverse problem / Обратная задача
│   ├── decoder.py              # Decoder wrapper / Обёртка декодера
│   ├── math_exact.py           # Exact math methods / Точные методы
│   ├── etalon.py               # Etalon system / Эталонная система
│   ├── normal_etalon.py        # Normal etalon / Нормальная система
│   ├── goal_system.py          # Goal system / Система целей
│   ├── secure.py               # Security / Безопасность
│   ├── rag.py                  # RAG module / RAG модуль
│   ├── xai.py                  # XAI module / XAI модуль
│   └── experimental/           # Experimental modules / Экспериментальные модули
│       ├── topological.py      # Topological methods / Топологические методы
│       └── physical/           # Physical module / Физический модуль
├── tests/                      # Unit tests / Модульные тесты
├── examples/                   # Examples / Примеры
│   └── demo.py
├── quick_test.py               # Quick check / Быстрая проверка
├── pyproject.toml              # Project config / Конфигурация
└── requirements.txt            # Dependencies / Зависимости
```

---

## 🔧 API Reference / API Справочник

### KokaoCore

```python
from kokao import KokaoCore, CoreConfig

config = CoreConfig(input_dim=10, seed=42)
core = KokaoCore(config)

# Methods / Методы:
core.signal(x)                    # Compute signal / Вычислить сигнал
core.train(x, target, lr, mode)   # Train / Обучение
core.train_batch(X, targets, lr)  # Batch train / Пакетное обучение
core.forget(rate, lambda_l1)      # Forgetting / Забывание
core.to_inverse_problem()         # Inverse problem / Обратная задача
```

### Decoder

```python
from kokao import Decoder

decoder = Decoder(core, lr=0.05, max_steps=200)
x_gen = decoder.generate(S_target=0.5)
```

### MathExactCore

```python
from kokao import MathExactCore, MathExactConfig

config = MathExactConfig(dtype=torch.float64)
math_core = MathExactCore(config)

# SVD pseudo-inverse / SVD псевдообращение
x = math_core.solve_inverse_svd(w_plus, w_minus, S_target)

# Spectral analysis / Спектральный анализ
spectrum = math_core.compute_spectrum(w_plus, w_minus)
```

### Experimental: TopologicalInverse

```python
from kokao.experimental import TopologicalInverse, K, check_fundamental_range, normalize_to_sphere

# K = 1838.684 (neutron/electron mass ratio)
# Фундаментальная константа (отношение масс нейтрона и электрона)

# Check signal range / Проверка диапазона сигнала
check_fundamental_range(1.0)  # True (в диапазоне [1/K, K])
check_fundamental_range(5000.0)  # False (вне диапазона)

# Normalize to unit sphere / Нормализация на сферу
x = torch.randn(10)
x_sphere = normalize_to_sphere(x)  # ||x_sphere|| = 1

# Inverse problem with topological checks
inv = TopologicalInverse(core, check_range=True, normalize_to_sphere=True)
x = inv.solve(target=0.8)  # решаем обратную задачу
```

### Experimental: Physical Module

```python
from kokao.experimental.physical import (
    PhysicalCore, PhysicalInverse,
    K, S3, ALPHA, A0,  # физические константы
    isospin_projection,  # изоспиновая проекция (+3/+4)
    solitonic_activation,  # солитонная активация (Синус-Гордон)
    quantize_with_topology,  # квантование по моде 93
    lorentz_factor  # лоренц-фактор
)

# PhysicalCore с изоспиновым режимом
core = PhysicalCore(config, isospin_mode='+3')
core.training = False  # для применения изоспиновой проекции
s = core.signal(x)

# PhysicalCore с солитонной активацией
core_sol = PhysicalCore(config, use_solitonic=True)
s = core_sol.signal(x)  # выход в диапазоне [-1, 1]

# PhysicalCore с лоренц-фактором
core_lor = PhysicalCore(config, use_lorentz=True, lorentz_c=1.0)
s = core_lor.signal(x)

# Обратная задача с физической проверкой
inv = PhysicalInverse(core, check_range=True)
x = inv.solve(target=0.8)

# Квантование с топологией
w = torch.randn(100)
w_q = quantize_with_topology(w, n_levels=93)
charge = topological_charge(w)  # топологический заряд
```

---

## 📄 License / Лицензия

Apache License 2.0 — See [LICENSE](LICENSE) for details.

**Authors / Авторы:**
- Vital Kalinouski / Виталий Калиновский
- V. Ovseychik / В.Овсейчик

**Organization / Организация:** newmathphys

Based on ideas from Yu.B. Kosyakov's book "My Brain" (1999).

Основано на идеях из книги Ю.Б. Косякова "Мой мозг" (1999).

**Note / Примечание:** The mathematical method is in the public domain (Russian Patent №2109332 expired).

Математический метод находится в общественном достоянии (патент РФ №2109332 утратил силу).

---

## 🤝 Contributing / Вклад

1. Fork the repository / Форкнуть репозиторий
2. Create a branch (`git checkout -b feature/AmazingFeature`) / Создать ветку
3. Commit changes (`git commit -m 'Add AmazingFeature'`) / Закоммитить изменения
4. Push to branch (`git push origin feature/AmazingFeature`) / Отправить в ветку
5. Open a Pull Request / Открыть Pull Request

---

## 📈 Statistics / Статистика

- **579 tests** covering all modules (including 41 experimental)
- **52 modules** implemented (including experimental)
- **800× speedup** on GPU with batch training
- **INT8/INT4 quantization** for edge devices
- **Physical interpretation** — Isospin, solitons, Lorentz factor, topology

---

## 🌐 Links / Ссылки

| Platform / Платформа | Version / Версия | Link / Ссылка |
|---------------------|------------------|---------------|
| **PyPI (stable)** | v3.0.3 | [pypi.org/project/kokao-engine](https://pypi.org/project/kokao-engine/3.0.3/) |
| **GitHub** | v2.0 | [github.com/newmathphys/kokao-engine](https://github.com/newmathphys/kokao-engine) |

---

*Last updated / Последнее обновление: March 2026*
